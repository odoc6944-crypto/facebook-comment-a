const reply = document.getElementById("reply");
const count = document.getElementById("count");
const notice = document.getElementById("notice");
const copyButton = document.getElementById("copyButton");

reply.addEventListener("input", () => {
  count.textContent = `${reply.value.length} / 1000`;
  notice.textContent = "";
});

copyButton.addEventListener("click", async () => {
  if (!reply.value.trim()) {
    notice.textContent = "Write a reply before copying.";
    return;
  }
  try {
    await navigator.clipboard.writeText(reply.value);
    notice.textContent = "Reply copied. You can paste it where you need it.";
  } catch {
    reply.select();
    notice.textContent = "Select the text and copy it manually.";
  }
});

document.getElementById("year").textContent = new Date().getFullYear();
