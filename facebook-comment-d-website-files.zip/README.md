# Social Reply Desk

A small, mobile-friendly starter website for drafting and copying social media replies.

## Files
- `index.html` — website page
- `style.css` — layout and design
- `script.js` — character counter and copy button

## Run it
Open `index.html` in a browser, or upload all four files to the root of your GitHub repository.

## Publish with GitHub Pages
1. Open your repository on GitHub.
2. Choose **Add file → Upload files**.
3. Upload `index.html`, `style.css`, `script.js`, and `README.md`.
4. Commit the changes.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
7. Wait for GitHub Pages to publish the site. Your public URL will appear in the Pages section.

## Safety note
This starter is a drafting tool only. It does not collect Facebook passwords, access Facebook accounts, or automatically post comments/messages. Any future Facebook integration should use Meta's official developer tools, approved permissions, and platform policies.
